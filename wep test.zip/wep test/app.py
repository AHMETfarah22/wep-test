# main.py
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import ttkbootstrap as tb
from ttkbootstrap.constants import *
import json
import os
from datetime import datetime
import random
import csv

# Nidaamka Xaqiijinta
class AuthSystem:
    USER_DATA_FILE = "users.json"
    ORDER_HISTORY_DIR = "order_history"
    
    @classmethod
    def load_users(cls):
        if os.path.exists(cls.USER_DATA_FILE):
            try:
                with open(cls.USER_DATA_FILE, 'r') as f:
                    return json.load(f)
            except:
                return {}
        return {}
    
    @classmethod
    def save_users(cls, users):
        with open(cls.USER_DATA_FILE, 'w') as f:
            json.dump(users, f, indent=4)
    
    @classmethod
    def register_user(cls, username, password):
        users = cls.load_users()
        if username in users:
            return False
        users[username] = {
            "password": password, 
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "role": "user"
        }
        cls.save_users(users)
        return True
    
    @classmethod
    def login_user(cls, username, password):
        users = cls.load_users()
        if username in users and users[username]["password"] == password:
            return users[username]
        return None
    
    @classmethod
    def save_order(cls, username, order_details):
        # Make sure the directory exists
        if not os.path.exists(cls.ORDER_HISTORY_DIR):
            os.makedirs(cls.ORDER_HISTORY_DIR)
        
        # Create user-specific order history file
        user_file = os.path.join(cls.ORDER_HISTORY_DIR, f"{username}_orders.json")
        
        orders = []
        if os.path.exists(user_file):
            try:
                with open(user_file, 'r') as f:
                    orders = json.load(f)
            except:
                orders = []
        
        # Add new order
        orders.append({
            "order_id": f"ORD-{random.randint(1000, 9999)}-{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "details": order_details
        })
        
        # Save back to file
        with open(user_file, 'w') as f:
            json.dump(orders, f, indent=4)
    
    @classmethod
    def load_orders(cls, username):
        user_file = os.path.join(cls.ORDER_HISTORY_DIR, f"{username}_orders.json")
        if os.path.exists(user_file):
            try:
                with open(user_file, 'r') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    @classmethod
    def load_all_orders(cls):
        all_orders = []
        if os.path.exists(cls.ORDER_HISTORY_DIR):
            for filename in os.listdir(cls.ORDER_HISTORY_DIR):
                if filename.endswith("_orders.json"):
                    try:
                        with open(os.path.join(cls.ORDER_HISTORY_DIR, filename), 'r') as f:
                            user_orders = json.load(f)
                            all_orders.extend(user_orders)
                    except:
                        continue
        return all_orders

# App-ka Aasaasiga ah
class FastFoodApp(tb.Window):
    def __init__(self):
        super().__init__(themename="darkly")
        self.title("🍔 Nidaamka Dalabka Cuntooyinka")
        self.geometry("1200x800")
        self.resizable(True, True)
        self.current_user = None
        self.user_role = None
        
        # Container-ka
        container = tb.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)
        
        self.frames = {}
        for F in (LoginPage, RegisterPage, DashboardPage, OrderPage, OrderHistoryPage, AdminPage, SettingsPage):
            page_name = F.__name__
            frame = F(parent=container, controller=self)
            self.frames[page_name] = frame
            frame.grid(row=0, column=0, sticky="nsew")
        
        self.show_frame("LoginPage")
    
    def show_frame(self, page_name):
        frame = self.frames[page_name]
        frame.tkraise()
        
        # Refresh data for specific pages
        if page_name == "DashboardPage":
            frame.refresh_data()
        elif page_name == "OrderHistoryPage":
            frame.load_orders()
        elif page_name == "AdminPage":
            frame.refresh_data()
    
    def logout(self):
        self.current_user = None
        self.user_role = None
        self.show_frame("LoginPage")

# Bogga Galidka
class LoginPage(tb.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        
        # Frame-ka Aasaasiga ah
        main_frame = tb.Frame(self, bootstyle="dark")
        main_frame.pack(fill="both", expand=True, padx=50, pady=50)
        
        # Madaxa
        header = tb.Frame(main_frame)
        header.pack(pady=(20, 10))
        
        logo = tb.Label(header, text="🍔", font=("Arial", 40))
        logo.pack(side="left", padx=10)
        
        title_frame = tb.Frame(header)
        title_frame.pack(side="left")
        
        tb.Label(title_frame, text="NIDAAMKA", font=("Arial", 24, "bold"), bootstyle="primary").pack(anchor="w")
        tb.Label(title_frame, text="Dalabka Cuntooyinka", font=("Arial", 18)).pack(anchor="w")
        
        # Qaabka
        form_frame = tb.Frame(main_frame)
        form_frame.pack(pady=30)
        
        self.username = tb.StringVar(value="admin")
        self.password = tb.StringVar(value="admin123")
        
        tb.Label(form_frame, text="Magaca Isticmaalaha", font=("Arial", 12)).grid(row=0, column=0, padx=10, pady=10, sticky="w")
        tb.Entry(form_frame, textvariable=self.username, width=30, font=("Arial", 12)).grid(row=0, column=1, padx=10, pady=10)
        
        tb.Label(form_frame, text="Furaha", font=("Arial", 12)).grid(row=1, column=0, padx=10, pady=10, sticky="w")
        tb.Entry(form_frame, textvariable=self.password, show="*", width=30, font=("Arial", 12)).grid(row=1, column=1, padx=10, pady=10)
        
        # Badhanno
        btn_frame = tb.Frame(main_frame)
        btn_frame.pack(pady=20)
        
        login_btn = tb.Button(btn_frame, text="Gali", bootstyle="success", width=15,
                             command=self.login, padding=10)
        login_btn.pack(side="left", padx=10)
        
        register_btn = tb.Button(btn_frame, text="Diiwaan Geliso", bootstyle="primary", 
                                command=lambda: controller.show_frame("RegisterPage"))
        register_btn.pack(side="left", padx=10)
        
        # Footer
        tb.Label(main_frame, text="© 2025 FastFood Inc. | Waxaa Abuurtay AFM", 
                font=("Arial", 8), bootstyle="secondary").pack(side="bottom", pady=10)
    
    def login(self):
        username = self.username.get()
        password = self.password.get()
        
        if not username or not password:
            messagebox.showerror("Khalad", "Fadlan geli magaca isticmaalaha iyo furaha")
            return
            
        user_data = AuthSystem.login_user(username, password)
        if user_data:
            self.controller.current_user = username
            self.controller.user_role = user_data.get("role", "user")
            self.controller.show_frame("DashboardPage")
        else:
            messagebox.showerror("Khalad", "Magaca isticmaalaha ama furaha waa khalad")

# Bogga Diiwaangelinta
class RegisterPage(tb.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        
        # Frame-ka Aasaasiga ah
        main_frame = tb.Frame(self)
        main_frame.pack(fill="both", expand=True, padx=50, pady=50)
        
        # Madaxa
        header = tb.Frame(main_frame)
        header.pack(pady=(20, 10))
        
        logo = tb.Label(header, text="📝", font=("Arial", 40))
        logo.pack(side="left", padx=10)
        
        title_frame = tb.Frame(header)
        title_frame.pack(side="left")
        
        tb.Label(title_frame, text="ABUUR AKOON", font=("Arial", 24, "bold"), bootstyle="primary").pack(anchor="w")
        tb.Label(title_frame, text="Ku biir bulshadeena", font=("Arial", 14)).pack(anchor="w")
        
        # Qaabka
        form_frame = tb.Frame(main_frame)
        form_frame.pack(pady=30)
        
        self.username = tb.StringVar()
        self.password = tb.StringVar()
        self.confirm_pass = tb.StringVar()
        
        tb.Label(form_frame, text="Magaca Isticmaalaha", font=("Arial", 12)).grid(row=0, column=0, padx=10, pady=10, sticky="w")
        tb.Entry(form_frame, textvariable=self.username, width=30, font=("Arial", 12)).grid(row=0, column=1, padx=10, pady=10)
        
        tb.Label(form_frame, text="Furaha", font=("Arial", 12)).grid(row=1, column=0, padx=10, pady=10, sticky="w")
        tb.Entry(form_frame, textvariable=self.password, show="*", width=30, font=("Arial", 12)).grid(row=1, column=1, padx=10, pady=10)
        
        tb.Label(form_frame, text="Xaqiiji Furaha", font=("Arial", 12)).grid(row=2, column=0, padx=10, pady=10, sticky="w")
        tb.Entry(form_frame, textvariable=self.confirm_pass, show="*", width=30, font=("Arial", 12)).grid(row=2, column=1, padx=10, pady=10)
        
        # Badhanno
        btn_frame = tb.Frame(form_frame)
        btn_frame.grid(row=3, column=1, padx=10, pady=10, sticky="e")
        
        register_btn = tb.Button(btn_frame, text="Diiwaan Geliso", bootstyle="success", width=15,
                               command=self.register, padding=10)
        register_btn.pack(side="left", padx=10)
        
        back_btn = tb.Button(btn_frame, text="Dib ugu Noqo", bootstyle="light",
                           command=lambda: controller.show_frame("LoginPage"))
        back_btn.pack(side="left", padx=10)
    
    def register(self):
        username = self.username.get()
        password = self.password.get()
        confirm_pass = self.confirm_pass.get()
        
        if not username or not password:
            messagebox.showerror("Khalad", "Fadlan geli magaca isticmaalaha iyo furaha")
            return
            
        if password != confirm_pass:
            messagebox.showerror("Khalad", "Furahu isma eka")
            return
            
        if AuthSystem.register_user(username, password):
            messagebox.showinfo("Guul", "Akoonka waa la abuuray!")
            self.controller.show_frame("LoginPage")
        else:
            messagebox.showerror("Khalad", "Magaca isticmaalaha hore ayaa loo isticmaalaa")

# Bogga Warbixinta
class DashboardPage(tb.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        
        # Madaxa
        header = tb.Frame(self, bootstyle="dark")
        header.pack(fill="x")
        
        tb.Label(header, text=f"Ku soo dhawoow, {self.controller.current_user}", 
                font=("Arial", 14), bootstyle="inverse").pack(side="left", padx=20, pady=10)
        
        nav_frame = tb.Frame(header)
        nav_frame.pack(side="right", padx=20)
        
        tb.Button(nav_frame, text="Dashboard", bootstyle="primary",
                 command=lambda: controller.show_frame("DashboardPage")).pack(side="left", padx=5)
        
        tb.Button(nav_frame, text="Dalabka", bootstyle="light-outline",
                 command=lambda: controller.show_frame("OrderPage")).pack(side="left", padx=5)
        
        tb.Button(nav_frame, text="Taariikhda Dalabka", bootstyle="light-outline",
                 command=lambda: controller.show_frame("OrderHistoryPage")).pack(side="left", padx=5)
        
        if self.controller.user_role == "admin":
            tb.Button(nav_frame, text="Maamulka", bootstyle="light-outline",
                     command=lambda: controller.show_frame("AdminPage")).pack(side="left", padx=5)
        
        tb.Button(nav_frame, text="Dejinta", bootstyle="light-outline",
                 command=lambda: controller.show_frame("SettingsPage")).pack(side="left", padx=5)
        
        tb.Button(nav_frame, text="Ka Bax", bootstyle="danger",
                 command=controller.logout).pack(side="left", padx=5)
        
        # Qaybta Mawduucyada
        main_frame = tb.Frame(self)
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Cinwaan
        tb.Label(main_frame, text="Warbixinta Iibka", font=("Arial", 24, "bold"), 
                bootstyle="primary").pack(pady=20)
        
        # Kaararka Xogta
        cards_frame = tb.Frame(main_frame)
        cards_frame.pack(fill="x", pady=20)
        
        cards = [
            {"title": "Wadarta Dalabyada", "value": "1,284", "change": "+12%", "icon": "📦", "style": "info"},
            {"title": "Dakhliga", "value": "$24,802", "change": "+18%", "icon": "💰", "style": "success"},
            {"title": "Macamiisha", "value": "8,492", "change": "+5%", "icon": "👥", "style": "warning"},
            {"title": "Raalli Galinta", "value": "94%", "change": "+2%", "icon": "⭐", "style": "danger"}
        ]
        
        for card in cards:
            card_frame = tb.Frame(cards_frame, bootstyle=card["style"], padding=10)
            card_frame.pack(side="left", fill="both", expand=True, padx=10)
            
            tb.Label(card_frame, text=card["icon"], font=("Arial", 24)).pack(anchor="nw")
            tb.Label(card_frame, text=card["title"], font=("Arial", 12)).pack(anchor="nw", pady=(10, 0))
            tb.Label(card_frame, text=card["value"], font=("Arial", 18, "bold")).pack(anchor="nw")
            tb.Label(card_frame, text=card["change"], font=("Arial", 10)).pack(anchor="nw", pady=(5, 0))
        
        # Jaantusyada
        charts_frame = tb.Frame(main_frame)
        charts_frame.pack(fill="both", expand=True, pady=20)
        
        # Jaantuska Iibka
        sales_frame = tb.Labelframe(charts_frame, text="📊 Iibka Bishii", bootstyle="info")
        sales_frame.pack(side="left", fill="both", expand=True, padx=10)
        
        chart_canvas = tb.Canvas(sales_frame, height=200)
        chart_canvas.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Samee jaantus bar
        sales_data = [12000, 18000, 15000, 24000, 21000, 19000, 24802]
        months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul"]
        
        max_sales = max(sales_data)
        bar_width = 30
        spacing = 20
        start_x = 50
        
        for i, (month, sales) in enumerate(zip(months, sales_data)):
            x0 = start_x + i * (bar_width + spacing)
            y0 = 180
            height = (sales / max_sales) * 150
            y1 = y0 - height
            
            chart_canvas.create_rectangle(x0, y0, x0 + bar_width, y1, fill="#3498db", outline="")
            chart_canvas.create_text(x0 + bar_width/2, y0 + 15, text=month, font=("Arial", 10))
            chart_canvas.create_text(x0 + bar_width/2, y1 - 10, text=f"${sales//1000}K", font=("Arial", 9))
        
        # Alaabta Caanka ah
        items_frame = tb.Labelframe(charts_frame, text="🍔 Alaabta Laga Dalbado", bootstyle="success")
        items_frame.pack(side="left", fill="both", expand=True, padx=10)
        
        items = [
            {"name": "Burger Birta", "orders": 284, "icon": "🍔"},
            {"name": "Pizza Baarmiil", "orders": 198, "icon": "🍕"},
            {"name": "Digaaga lug", "orders": 176, "icon": "🍗"},
            {"name": "Saladh Faransiis", "orders": 312, "icon": "🍟"},
            {"name": "Coca Cola", "orders": 412, "icon": "🥤"}
        ]
        
        for item in items:
            item_frame = tb.Frame(items_frame)
            item_frame.pack(fill="x", padx=10, pady=5)
            
            tb.Label(item_frame, text=item["icon"], font=("Arial", 14)).pack(side="left", padx=5)
            tb.Label(item_frame, text=item["name"], font=("Arial", 12)).pack(side="left", padx=5, fill="x", expand=True)
            tb.Label(item_frame, text=f"{item['orders']} dalab", font=("Arial", 12), bootstyle="primary").pack(side="right")
        
        # Footer
        tb.Label(self, text="© 2025 FastFood Inc. | Dashboard v1.0", 
                font=("Arial", 8), bootstyle="secondary").pack(side="bottom", pady=5)
    
    def refresh_data(self):
        # Halkan waxaa lagu cusbooneysiin karaa xogta
        pass

# Bogga Dalabka
class OrderPage(tb.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.cart = {}
        
        # Madaxa
        header = tb.Frame(self, bootstyle="dark")
        header.pack(fill="x")
        
        tb.Label(header, text=f"Dalabaya: {self.controller.current_user}", 
                font=("Arial", 14), bootstyle="inverse").pack(side="left", padx=20, pady=10)
        
        nav_frame = tb.Frame(header)
        nav_frame.pack(side="right", padx=20)
        
        tb.Button(nav_frame, text="Dashboard", bootstyle="light-outline",
                 command=lambda: controller.show_frame("DashboardPage")).pack(side="left", padx=5)
        
        tb.Button(nav_frame, text="Dalabka", bootstyle="primary", state="disabled").pack(side="left", padx=5)
        
        tb.Button(nav_frame, text="Taariikhda Dalabka", bootstyle="light-outline",
                 command=lambda: controller.show_frame("OrderHistoryPage")).pack(side="left", padx=5)
        
        tb.Button(nav_frame, text="Ka Bax", bootstyle="danger",
                 command=controller.logout).pack(side="left", padx=5)
        
        # Qaybta Mawduucyada
        main_frame = tb.Frame(self)
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Cinwaan
        tb.Label(main_frame, text="🍔 Dalab Cuntooyin Caano", 
                font=("Arial", 24, "bold"), bootstyle="primary").pack(pady=10)
        
        # Frame-ka Mawduucyada
        content_frame = tb.Frame(main_frame)
        content_frame.pack(fill="both", expand=True)
        
        # Bidix - Menu
        menu_frame = tb.Labelframe(content_frame, text="Menu", bootstyle="info")
        menu_frame.pack(side="left", fill="both", expand=True, padx=(0, 10), pady=10)
        
        self.menu_items = [
            {"name": "Burger", "price": 12.99, "icon": "🍔", "description": "Burger salaadiyo tamandho"},
            {"name": "Pizza Baarmiil", "price": 16.99, "icon": "🍕", "description": "Pizza caadi ah leh baarmiil iyo birta"},
            {"name": "Baalaadhka Digaaga", "price": 14.99, "icon": "🍗", "description": "Baalaadh digaag oo qallalan"},
            {"name": "Saladh Faransiis", "price": 5.99, "icon": "🍟", "description": "Saladh faransiis oo cagaaran"},
            {"name": "Saladh Siisaar", "price": 9.99, "icon": "🥗", "description": "Salaad cusbey leh saliid Siisaar"},
            {"name": "Coca Cola", "price": 2.99, "icon": "🥤", "description": "Coca Cola oo qabow"},
            {"name": "Shaah", "price": 3.99, "icon": "☕", "description": "Shaah diiran oo kulul"},
            {"name": "Keeg Dhexdhexaad", "price": 7.99, "icon": "🍰", "description": "Keeg caleen macaan"},
            {"name": "Burger Vegan", "price": 13.99, "icon": "🥬", "description": "Burger cagaar oo vegan ah"},
            {"name": "Pizza Vegan", "price": 17.99, "icon": "🍕", "description": "Pizza vegan ah oo khudaarta badan"}
        ]
        
        # Add a search bar
        search_frame = tb.Frame(menu_frame)
        search_frame.pack(fill="x", padx=10, pady=5)
        
        self.search_var = tb.StringVar()
        search_entry = tb.Entry(search_frame, textvariable=self.search_var, width=30, 
                              font=("Arial", 12), bootstyle="light")
        search_entry.pack(side="left", fill="x", expand=True, padx=(0, 5))
        search_entry.bind("<KeyRelease>", self.filter_menu)
        
        tb.Button(search_frame, text="Raadi", bootstyle="primary", 
                 command=self.filter_menu).pack(side="left")
        
        # Scrollable menu container
        menu_container = tb.Frame(menu_frame)
        menu_container.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Create canvas and scrollbar
        self.canvas = tb.Canvas(menu_container)
        scrollbar = tb.Scrollbar(menu_container, orient="vertical", command=self.canvas.yview)
        self.scrollable_frame = tb.Frame(self.canvas)
        
        self.scrollable_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        
        self.canvas.create_window((0, 0), window=self.scrollable_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=scrollbar.set)
        
        scrollbar.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        
        # Display menu items
        self.display_menu_items(self.menu_items)
        
        # Midig - Cart iyo Macluumaadka Macmiilka
        right_frame = tb.Frame(content_frame)
        right_frame.pack(side="left", fill="both", expand=True, padx=(10, 0), pady=10)
        
        # Macluumaadka Macmiilka
        info_frame = tb.Labelframe(right_frame, text="Macluumaadka Macmiilka", bootstyle="primary")
        info_frame.pack(fill="x", pady=(0, 10))
        
        self.name_var = tb.StringVar()
        self.phone_var = tb.StringVar()
        self.address_var = tb.StringVar()
        
        tb.Label(info_frame, text="Magaca Oo Dhameystiran", font=("Arial", 12)).pack(anchor="w", pady=(10, 0), padx=10)
        tb.Entry(info_frame, textvariable=self.name_var, font=("Arial", 12)).pack(fill="x", padx=10, pady=5)
        
        tb.Label(info_frame, text="Lambarka Taleefanka", font=("Arial", 12)).pack(anchor="w", pady=(10, 0), padx=10)
        tb.Entry(info_frame, textvariable=self.phone_var, font=("Arial", 12)).pack(fill="x", padx=10, pady=5)
        
        tb.Label(info_frame, text="Cinwaanka Gaarsiinta", font=("Arial", 12)).pack(anchor="w", pady=(10, 0), padx=10)
        tb.Entry(info_frame, textvariable=self.address_var, font=("Arial", 12)).pack(fill="x", padx=10, pady=5)
        
        # Cart
        cart_frame = tb.Labelframe(right_frame, text="Dalabkaaga", bootstyle="success")
        cart_frame.pack(fill="both", expand=True)
        
        # Madaxa Cart-ka
        cart_header = tb.Frame(cart_frame)
        cart_header.pack(fill="x", padx=10, pady=10)
        
        tb.Label(cart_header, text="Alaabta", font=("Arial", 12, "bold"), width=30).pack(side="left")
        tb.Label(cart_header, text="Tirada", font=("Arial", 12, "bold")).pack(side="left", padx=10)
        tb.Label(cart_header, text="Qiimaha", font=("Arial", 12, "bold")).pack(side="right")
        
        # Alaabta Cart-ka
        cart_container_frame = tb.Frame(cart_frame)
        cart_container_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Create canvas and scrollbar for cart
        self.cart_canvas = tb.Canvas(cart_container_frame)
        cart_scrollbar = tb.Scrollbar(cart_container_frame, orient="vertical", command=self.cart_canvas.yview)
        self.cart_container = tb.Frame(self.cart_canvas)
        
        self.cart_container.bind(
            "<Configure>",
            lambda e: self.cart_canvas.configure(scrollregion=self.cart_canvas.bbox("all"))
        )
        
        self.cart_canvas.create_window((0, 0), window=self.cart_container, anchor="nw")
        self.cart_canvas.configure(yscrollcommand=cart_scrollbar.set)
        
        cart_scrollbar.pack(side="right", fill="y")
        self.cart_canvas.pack(side="left", fill="both", expand=True)
        
        # Footer-ka Cart-ka
        cart_footer = tb.Frame(cart_frame)
        cart_footer.pack(fill="x", padx=10, pady=10)
        
        self.total_label = tb.Label(cart_footer, text="Wadarta: $0.00", font=("Arial", 14, "bold"), bootstyle="warning")
        self.total_label.pack(side="right")
        
        # Initialize empty cart
        self.update_cart_display()
        
        # Badhanno
        btn_frame = tb.Frame(right_frame)
        btn_frame.pack(fill="x", pady=10)
        
        tb.Button(btn_frame, text="Nadiif Cart", bootstyle="danger",
                 command=self.clear_cart).pack(side="left", padx=5)
        
        tb.Button(btn_frame, text="Geli Dalabka", bootstyle="success",
                 command=self.place_order).pack(side="right", padx=5)
    
    def display_menu_items(self, items):
        # Clear existing items
        for widget in self.scrollable_frame.winfo_children():
            widget.destroy()
        
        # Display filtered items
        for item in items:
            item_frame = tb.Frame(self.scrollable_frame, padding=10)
            item_frame.pack(fill="x", pady=5)
            
            tb.Label(item_frame, text=item["icon"], font=("Arial", 20)).pack(side="left", padx=10)
            
            text_frame = tb.Frame(item_frame)
            text_frame.pack(side="left", fill="x", expand=True)
            
            tb.Label(text_frame, text=item["name"], font=("Arial", 14, "bold")).pack(anchor="w")
            tb.Label(text_frame, text=item["description"], font=("Arial", 10), bootstyle="secondary").pack(anchor="w")
            
            price_frame = tb.Frame(item_frame)
            price_frame.pack(side="right")
            
            tb.Label(price_frame, text=f"${item['price']}", font=("Arial", 14, "bold"), 
                    bootstyle="warning").pack(side="left", padx=10)
            
            add_btn = tb.Button(price_frame, text="+ Dar", bootstyle="success", width=6,
                              command=lambda i=item: self.add_to_cart(i))
            add_btn.pack(side="left")
        
        # Update canvas scrolling
        self.canvas.update_idletasks()
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
    
    def filter_menu(self, event=None):
        search_term = self.search_var.get().lower()
        if not search_term:
            self.display_menu_items(self.menu_items)
            return
        
        filtered = [item for item in self.menu_items 
                   if search_term in item["name"].lower() 
                   or search_term in item["description"].lower()]
        self.display_menu_items(filtered)
    
    def add_to_cart(self, item):
        name = item["name"]
        if name in self.cart:
            self.cart[name]["quantity"] += 1
        else:
            self.cart[name] = {
                "item": item,
                "quantity": 1
            }
        self.update_cart_display()
    
    def clear_cart(self):
        self.cart = {}
        self.update_cart_display()
    
    def update_cart_display(self):
        # Tirtir alaabta hore
        for widget in self.cart_container.winfo_children():
            widget.destroy()
        
        total = 0
        
        if not self.cart:
            tb.Label(self.cart_container, text="Cart-kaaga waa madhan", 
                    font=("Arial", 12), bootstyle="secondary").pack(pady=20)
            self.total_label.config(text="Wadarta: $0.00")
            return
        
        for name, data in self.cart.items():
            item = data["item"]
            quantity = data["quantity"]
            item_total = item["price"] * quantity
            total += item_total
            
            item_frame = tb.Frame(self.cart_container)
            item_frame.pack(fill="x", pady=5)
            
            tb.Label(item_frame, text=f"{item['icon']} {name}", 
                    font=("Arial", 12), width=30).pack(side="left")
            
            # Xakamaynta Tirada
            qty_frame = tb.Frame(item_frame)
            qty_frame.pack(side="left", padx=10)
            
            tb.Button(qty_frame, text="-", width=2, bootstyle="outline",
                     command=lambda n=name: self.update_quantity(n, -1)).pack(side="left")
            tb.Label(qty_frame, text=str(quantity), width=3, 
                    font=("Arial", 12)).pack(side="left", padx=3)
            tb.Button(qty_frame, text="+", width=2, bootstyle="outline",
                     command=lambda n=name: self.update_quantity(n, 1)).pack(side="left")

            tb.Label(item_frame, text=f"${item_total:.2f}", 
                    font=("Arial", 12), bootstyle="warning").pack(side="right")
        
        self.total_label.config(text=f"Wadarta: ${total:.2f}")
        
        # Update canvas scrolling
        self.cart_canvas.update_idletasks()
        self.cart_canvas.configure(scrollregion=self.cart_canvas.bbox("all"))
    
    def update_quantity(self, name, change):
        if name in self.cart:
            self.cart[name]["quantity"] += change
            if self.cart[name]["quantity"] <= 0:
                del self.cart[name]
            self.update_cart_display()
    
    def place_order(self):
        name = self.name_var.get()
        phone = self.phone_var.get()
        address = self.address_var.get()
        
        if not name or not phone or not address:
            messagebox.showerror("Khalad", "Fadlan buuxi macluumaadka macmiilka")
            return
            
        if not self.cart:
            messagebox.showerror("Khalad", "Cart-kaaga waa madhan")
            return
            
        # Samee warbixinta dalabka
        order_summary = "Warbixinta Dalabka:\n\n"
        order_summary += f"Macmiilka: {name}\n"
        order_summary += f"Taleefanka: {phone}\n"
        order_summary += f"Cinwaanka: {address}\n\n"
        order_summary += "Alaabta:\n"
        
        order_details = {
            "customer_name": name,
            "phone": phone,
            "address": address,
            "items": []
        }
        
        total = 0
        for name, data in self.cart.items():
            item = data["item"]
            quantity = data["quantity"]
            item_total = item["price"] * quantity
            total += item_total
            order_summary += f"  - {item['icon']} {name} x{quantity}: ${item_total:.2f}\n"
            
            order_details["items"].append({
                "name": name,
                "price": item["price"],
                "quantity": quantity,
                "total": item_total
            })
        
        order_summary += f"\nWadarta: ${total:.2f}"
        order_details["total"] = total
        
        # Xaqiiji dalabka
        confirm = messagebox.askyesno("Xaqiiji Dalabka", f"{order_summary}\n\nMa rabtaa inaad dalabta gelisid?")
        if confirm:
            # Save the order
            AuthSystem.save_order(self.controller.current_user, order_details)
            
            messagebox.showinfo("Guul", "Dalabka waa lagu guuleystay!")
            self.clear_cart()
            self.name_var.set("")
            self.phone_var.set("")
            self.address_var.set("")
            self.controller.show_frame("DashboardPage")

# Bogga Taariikhda Dalabka
class OrderHistoryPage(tb.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        
        # Madaxa
        header = tb.Frame(self, bootstyle="dark")
        header.pack(fill="x")
        
        tb.Label(header, text=f"Taariikhda Dalabka: {self.controller.current_user}", 
                font=("Arial", 14), bootstyle="inverse").pack(side="left", padx=20, pady=10)
        
        nav_frame = tb.Frame(header)
        nav_frame.pack(side="right", padx=20)
        
        tb.Button(nav_frame, text="Dashboard", bootstyle="light-outline",
                 command=lambda: controller.show_frame("DashboardPage")).pack(side="left", padx=5)
        
        tb.Button(nav_frame, text="Dalabka", bootstyle="light-outline",
                 command=lambda: controller.show_frame("OrderPage")).pack(side="left", padx=5)
        
        tb.Button(nav_frame, text="Taariikhda Dalabka", bootstyle="primary", state="disabled").pack(side="left", padx=5)
        
        tb.Button(nav_frame, text="Ka Bax", bootstyle="danger",
                 command=controller.logout).pack(side="left", padx=5)
        
        # Qaybta Mawduucyada
        main_frame = tb.Frame(self)
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Cinwaan
        tb.Label(main_frame, text="📋 Taariikhda Dalabka", 
                font=("Arial", 24, "bold"), bootstyle="primary").pack(pady=10)
        
        # Frame-ka Jadwalka
        table_frame = tb.Frame(main_frame)
        table_frame.pack(fill="both", expand=True, pady=10)
        
        # Jadwalka Taariikhda Dalabka
        columns = ("id", "date", "customer", "total", "status")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=10)
        
        # Define headings
        self.tree.heading("id", text="Aqoonsiga Dalabka")
        self.tree.heading("date", text="Taariikhda")
        self.tree.heading("customer", text="Macmiilka")
        self.tree.heading("total", text="Wadarta")
        self.tree.heading("status", text="Xaaladda")
        
        # Set column widths
        self.tree.column("id", width=150, anchor="center")
        self.tree.column("date", width=150, anchor="center")
        self.tree.column("customer", width=200, anchor="center")
        self.tree.column("total", width=100, anchor="center")
        self.tree.column("status", width=100, anchor="center")
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar.set)
        
        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Footer with buttons
        footer_frame = tb.Frame(main_frame)
        footer_frame.pack(fill="x", pady=10)
        
        tb.Button(footer_frame, text="Dib u soo celi", bootstyle="info",
                 command=self.load_orders).pack(side="left", padx=5)
        
        tb.Button(footer_frame, text="Daawo Dalabka", bootstyle="success",
                 command=self.view_order_details).pack(side="left", padx=5)
        
        tb.Button(footer_frame, text="Soo Deg", bootstyle="secondary",
                 command=self.export_to_csv).pack(side="right", padx=5)
        
        # Load initial orders
        self.load_orders()
    
    def load_orders(self):
        # Clear existing data
        for item in self.tree.get_children():
            self.tree.delete(item)
        
        # Load orders based on user role
        if self.controller.user_role == "admin":
            orders = AuthSystem.load_all_orders()
        else:
            orders = AuthSystem.load_orders(self.controller.current_user)
        
        # Add orders to the treeview
        for order in orders:
            customer = order["details"].get("customer_name", "Lama hayo")
            total = f"${order['details'].get('total', 0):.2f}"
            self.tree.insert("", "end", values=(
                order["order_id"],
                order["timestamp"],
                customer,
                total,
                "La Fuliyay"
            ))
    
    def view_order_details(self):
        selected = self.tree.focus()
        if not selected:
            messagebox.showwarning("Ogow", "Fadlan dooro dalab si aad u daawato")
            return
        
        item = self.tree.item(selected)
        order_id = item["values"][0]
        
        # Load orders to find this one
        if self.controller.user_role == "admin":
            orders = AuthSystem.load_all_orders()
        else:
            orders = AuthSystem.load_orders(self.controller.current_user)
        
        order_details = next((o for o in orders if o["order_id"] == order_id), None)
        if not order_details:
            messagebox.showerror("Khalad", "Dalabka lama helin")
            return
        
        # Show order details in a messagebox
        details = f"Aqoonsiga Dalabka: {order_details['order_id']}\n"
        details += f"Taariikhda: {order_details['timestamp']}\n"
        details += f"Macmiilka: {order_details['details']['customer_name']}\n"
        details += f"Taleefanka: {order_details['details']['phone']}\n"
        details += f"Cinwaanka: {order_details['details']['address']}\n\n"
        details += "Alaabta:\n"
        
        for item in order_details["details"]["items"]:
            details += f"  - {item['name']} x{item['quantity']}: ${item['total']:.2f}\n"
        
        details += f"\nWadarta: ${order_details['details']['total']:.2f}"
        
        messagebox.showinfo("Faahfaahinta Dalabka", details)
    
    def export_to_csv(self):
        file_path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("Faylka CSV", "*.csv"), ("Dhammaan Faylasha", "*.*")]
        )
        
        if not file_path:
            return
        
        # Get orders
        if self.controller.user_role == "admin":
            orders = AuthSystem.load_all_orders()
        else:
            orders = AuthSystem.load_orders(self.controller.current_user)
        
        # Prepare data for CSV
        data = []
        for order in orders:
            for item in order["details"]["items"]:
                data.append({
                    "Order ID": order["order_id"],
                    "Date": order["timestamp"],
                    "Customer": order["details"]["customer_name"],
                    "Phone": order["details"]["phone"],
                    "Address": order["details"]["address"],
                    "Item": item["name"],
                    "Quantity": item["quantity"],
                    "Price": item["price"],
                    "Total": item["total"],
                    "Order Total": order["details"]["total"]
                })
        
        # Write to CSV
        try:
            with open(file_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=data[0].keys())
                writer.writeheader()
                writer.writerows(data)
            messagebox.showinfo("Guul", "Warbixinta ayaa loo soo dejisay si guul leh!")
        except Exception as e:
            messagebox.showerror("Khalad", f"Khalad ayaa dhacay: {str(e)}")

# Bogga Maamulka
class AdminPage(tb.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        
        # Madaxa
        header = tb.Frame(self, bootstyle="dark")
        header.pack(fill="x")
        
        tb.Label(header, text=f"Maamulka: {self.controller.current_user}", 
                font=("Arial", 14), bootstyle="inverse").pack(side="left", padx=20, pady=10)
        
        nav_frame = tb.Frame(header)
        nav_frame.pack(side="right", padx=20)
        
        tb.Button(nav_frame, text="Dashboard", bootstyle="light-outline",
                 command=lambda: controller.show_frame("DashboardPage")).pack(side="left", padx=5)
        
        tb.Button(nav_frame, text="Dalabka", bootstyle="light-outline",
                 command=lambda: controller.show_frame("OrderPage")).pack(side="left", padx=5)
        
        tb.Button(nav_frame, text="Taariikhda Dalabka", bootstyle="light-outline",
                 command=lambda: controller.show_frame("OrderHistoryPage")).pack(side="left", padx=5)
        
        tb.Button(nav_frame, text="Maamulka", bootstyle="primary", state="disabled").pack(side="left", padx=5)
        
        tb.Button(nav_frame, text="Ka Bax", bootstyle="danger",
                 command=controller.logout).pack(side="left", padx=5)
        
        # Qaybta Mawduucyada
        main_frame = tb.Frame(self)
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Tab Control
        self.notebook = tb.Notebook(main_frame, bootstyle="dark")
        self.notebook.pack(fill="both", expand=True, pady=10)
        
        # Tab-ka Isticmaalayaasha
        users_tab = tb.Frame(self.notebook)
        self.notebook.add(users_tab, text="Isticmaalayaasha")
        
        # Jadwalka Isticmaalayaasha
        users_frame = tb.Frame(users_tab)
        users_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Jadwalka Isticmaalayaasha
        columns = ("username", "created_at", "role")
        self.users_tree = ttk.Treeview(users_frame, columns=columns, show="headings", height=10)
        
        # Define headings
        self.users_tree.heading("username", text="Magaca Isticmaalaha")
        self.users_tree.heading("created_at", text="Taariikhda Abuurista")
        self.users_tree.heading("role", text="Doorka")
        
        # Set column widths
        self.users_tree.column("username", width=200, anchor="center")
        self.users_tree.column("created_at", width=200, anchor="center")
        self.users_tree.column("role", width=100, anchor="center")
        
        # Add scrollbar
        scrollbar = ttk.Scrollbar(users_frame, orient="vertical", command=self.users_tree.yview)
        self.users_tree.configure(yscrollcommand=scrollbar.set)
        
        self.users_tree.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Badhanno Isticmaalayaasha
        users_btn_frame = tb.Frame(users_tab)
        users_btn_frame.pack(fill="x", pady=10)
        
        tb.Button(users_btn_frame, text="Dib u soo celi", bootstyle="info",
                 command=self.load_users).pack(side="left", padx=5)
        
        tb.Button(users_btn_frame, text="Tirtir", bootstyle="danger",
                 command=self.delete_user).pack(side="left", padx=5)
        
        # Tab-ka Warbixinta
        reports_tab = tb.Frame(self.notebook)
        self.notebook.add(reports_tab, text="Warbixinta")
        
        # Warbixinta
        reports_frame = tb.Frame(reports_tab)
        reports_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        # Cinwaan Warbixinta
        tb.Label(reports_frame, text="Warbixinta Iibka", font=("Arial", 16, "bold"), 
                bootstyle="primary").pack(anchor="w", pady=(0, 10))
        
        # Badhanno Warbixinta
        reports_btn_frame = tb.Frame(reports_frame)
        reports_btn_frame.pack(fill="x", pady=10)
        
        tb.Button(reports_btn_frame, text="Soo Deg Warbixinta", bootstyle="success",
                 command=self.export_report).pack(side="right", padx=5)
        
        # Qaybta Stats-ka
        stats_frame = tb.Frame(reports_frame)
        stats_frame.pack(fill="x", pady=10)
        
        stats = [
            {"title": "Wadarta Dalabyada", "value": "1,284", "icon": "📦"},
            {"title": "Wadarta Dakhliga", "value": "$24,802", "icon": "💰"},
            {"title": "Isticmaalayaasha", "value": "42", "icon": "👥"},
            {"title": "Dalabyada Maanta", "value": "28", "icon": "📝"}
        ]
        
        for stat in stats:
            stat_frame = tb.Frame(stats_frame, bootstyle="light", padding=10)
            stat_frame.pack(side="left", fill="both", expand=True, padx=5)
            
            tb.Label(stat_frame, text=stat["icon"], font=("Arial", 24)).pack(side="left", padx=10)
            
            text_frame = tb.Frame(stat_frame)
            text_frame.pack(side="left")
  
            tb.Label(text_frame, text=stat["title"], font=("Arial", 12)).pack(anchor="w")
            tb.Label(text_frame, text=stat["value"], font=("Arial", 14, "bold")).pack(anchor="w")
        
        # Load initial data
        self.load_users()
    
    def refresh_data(self):
        self.load_users()
    
    def load_users(self):
        # Clear existing data
        for item in self.users_tree.get_children():
            self.users_tree.delete(item)
        
        # Load users
        users = AuthSystem.load_users()
        for username, data in users.items():
            self.users_tree.insert("", "end", values=(
                username,
                data["created_at"],
                data.get("role", "user")
            ))
    
    def delete_user(self):
        selected = self.users_tree.focus()
        if not selected:
            messagebox.showwarning("Ogow", "Fadlan dooro isticmaale")
            return
        
        item = self.users_tree.item(selected)
        username = item["values"][0]
        
        if username == self.controller.current_user:
            messagebox.showerror("Khalad", "Ma tirtiri kartid akoonkaaga!")
            return
            
        confirm = messagebox.askyesno("Xaqiiji", f"Ma hubtaa inaad rabto inaad tirtirto isticmaalaha {username}?")
        if confirm:
            users = AuthSystem.load_users()
            if username in users:
                del users[username]
                AuthSystem.save_users(users)
                self.load_users()
                messagebox.showinfo("Guul", "Isticmaalaha waa la tirtiray")

    def export_report(self):
        file_path = filedialog.asksaveasfilename(
            defaultextension=".csv",
            filetypes=[("Faylka CSV", "*.csv"), ("Dhammaan Faylasha", "*.*")]
        )
        
        if not file_path:
            return
        
        # Get all orders
        orders = AuthSystem.load_all_orders()
        
        # Prepare data for CSV
        data = []
        for order in orders:
            for item in order["details"]["items"]:
                data.append({
                    "Order ID": order["order_id"],
                    "Date": order["timestamp"],
                    "Customer": order["details"]["customer_name"],
                    "Phone": order["details"]["phone"],
                    "Address": order["details"]["address"],
                    "Item": item["name"],
                    "Quantity": item["quantity"],
                    "Price": item["price"],
                    "Total": item["total"],
                    "Order Total": order["details"]["total"]
                })
        
        # Write to CSV
        try:
            with open(file_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=data[0].keys())
                writer.writeheader()
                writer.writerows(data)
            messagebox.showinfo("Guul", "Warbixinta ayaa loo soo dejisay si guul leh!")
        except Exception as e:
            messagebox.showerror("Khalad", f"Khalad ayaa dhacay: {str(e)}")

# Bogga Dejinta
class SettingsPage(tb.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        
        # Madaxa
        header = tb.Frame(self, bootstyle="dark")
        header.pack(fill="x")
        
        tb.Label(header, text=f"Dejinta: {self.controller.current_user}", 
                font=("Arial", 14), bootstyle="inverse").pack(side="left", padx=20, pady=10)
        
        nav_frame = tb.Frame(header)
        nav_frame.pack(side="right", padx=20)
        
        tb.Button(nav_frame, text="Dashboard", bootstyle="light-outline",
                 command=lambda: controller.show_frame("DashboardPage")).pack(side="left", padx=5)
        
        tb.Button(nav_frame, text="Dalabka", bootstyle="light-outline",
                 command=lambda: controller.show_frame("OrderPage")).pack(side="left", padx=5)
        
        tb.Button(nav_frame, text="Taariikhda Dalabka", bootstyle="light-outline",
                 command=lambda: controller.show_frame("OrderHistoryPage")).pack(side="left", padx=5)
        
        tb.Button(nav_frame, text="Dejinta", bootstyle="primary", state="disabled").pack(side="left", padx=5)
        
        tb.Button(nav_frame, text="Ka Bax", bootstyle="danger",
                 command=controller.logout).pack(side="left", padx=5)
        
        # Qaybta Mawduucyada
        main_frame = tb.Frame(self)
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Cinwaan
        tb.Label(main_frame, text="🚀 Dejinta Akoonka", 
                font=("Arial", 24, "bold"), bootstyle="primary").pack(pady=10)
        
        # Qaabka Beddelka Furaha
        form_frame = tb.Labelframe(main_frame, text="Beddelka Furaha", bootstyle="info")
        form_frame.pack(fill="x", padx=20, pady=10)
        
        self.old_password = tb.StringVar()
        self.new_password = tb.StringVar()
        self.confirm_password = tb.StringVar()
        
        tb.Label(form_frame, text="Furaha Hore", font=("Arial", 12)).grid(row=0, column=0, padx=10, pady=10, sticky="w")
        tb.Entry(form_frame, textvariable=self.old_password, show="*", width=30, font=("Arial", 12)).grid(row=0, column=1, padx=10, pady=10)
        
        tb.Label(form_frame, text="Furaha Cusub", font=("Arial", 12)).grid(row=1, column=0, padx=10, pady=10, sticky="w")
        tb.Entry(form_frame, textvariable=self.new_password, show="*", width=30, font=("Arial", 12)).grid(row=1, column=1, padx=10, pady=10)
        
        tb.Label(form_frame, text="Xaqiiji Furaha Cusub", font=("Arial", 12)).grid(row=2, column=0, padx=10, pady=10, sticky="w")
        tb.Entry(form_frame, textvariable=self.confirm_password, show="*", width=30, font=("Arial", 12)).grid(row=2, column=1, padx=10, pady=10)
        
        # Badhanno
        btn_frame = tb.Frame(form_frame)
        btn_frame.grid(row=3, column=1, padx=10, pady=10, sticky="e")
        
        tb.Button(btn_frame, text="Keydi Furaha", bootstyle="success",
                 command=self.change_password).pack(side="left", padx=5)
        
        # Qaybta Theme-ka
        theme_frame = tb.Labelframe(main_frame, text="Habka Muuqaalka", bootstyle="info")
        theme_frame.pack(fill="x", padx=20, pady=10)
        
        self.theme_var = tb.StringVar(value="darkly")
        
        themes = [
            ("Darkly", "darkly"),
            ("Superhero", "superhero"),
            ("Solar", "solar"),
            ("Cyborg", "cyborg"),
            ("Vapor", "vapor"),
            ("Morph", "morph"),
            ("Litera", "litera")
        ]
        
        for i, (name, theme) in enumerate(themes):
            rb = tb.Radiobutton(theme_frame, text=name, variable=self.theme_var, 
                               value=theme, bootstyle="primary")
            rb.grid(row=i//3, column=i%3, padx=10, pady=5, sticky="w")
        
        tb.Button(theme_frame, text="Cusbooneysii Muuqaalka", bootstyle="primary",
                 command=self.apply_theme).grid(row=2, column=0, columnspan=3, sticky="e", padx=10, pady=10)
    
    def change_password(self):
        old_pass = self.old_password.get()
        new_pass = self.new_password.get()
        confirm_pass = self.confirm_password.get()
        
        if not old_pass or not new_pass or not confirm_pass:
            messagebox.showerror("Khalad", "Fadlan buuxi dhammaan goobaha")
            return
            
        if new_pass != confirm_pass:
            messagebox.showerror("Khalad", "Furaha cusub isma eka")
            return
            
        # Verify old password
        users = AuthSystem.load_users()
        username = self.controller.current_user
        
        if username not in users or users[username]["password"] != old_pass:
            messagebox.showerror("Khalad", "Furaha hore waa khalad")
            return
            
        # Update password
        users[username]["password"] = new_pass
        AuthSystem.save_users(users)
        
        messagebox.showinfo("Guul", "Furaha waa la cusboonaysiiyay!")
        self.old_password.set("")
        self.new_password.set("")
        self.confirm_password.set("")
    
    def apply_theme(self):
        theme = self.theme_var.get()
        self.controller.style.theme_use(theme)
        messagebox.showinfo("Guul", f"Muuqaalka waa la beddelay: {theme}")

# Ku ciyaar app-ka
if __name__ == "__main__":
    # Create admin user if not exists
    users = AuthSystem.load_users()
    if "admin" not in users:
        users["admin"] = {
            "password": "admin123",
            "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "role": "admin"
        }
        AuthSystem.save_users(users)
    
    app = FastFoodApp()
    app.mainloop()