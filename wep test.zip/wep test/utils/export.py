from reportlab.pdfgen import canvas
from openpyxl import Workbook

def export_to_pdf(filename, text="Hello PDF"):
    c = canvas.Canvas(filename)
    c.drawString(100, 750, text)
    c.save()

def export_to_excel(filename, data=[["Header1", "Header2"], ["Row1Col1", "Row1Col2"]]):
    wb = Workbook()
    ws = wb.active
    for row in data:
        ws.append(row)
    wb.save(filename)
