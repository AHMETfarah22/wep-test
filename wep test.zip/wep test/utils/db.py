import sqlite3

conn = sqlite3.connect("database.db")
cursor = conn.cursor()
cursor.execute("""
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    food TEXT
)
""")
conn.commit()

def insert_order(name, food):
    cursor.execute("INSERT INTO orders (name, food) VALUES (?, ?)", (name, food))
    conn.commit()

def fetch_orders():
    cursor.execute("SELECT name, food FROM orders")
    return cursor.fetchall()
