import tkinter as tk

class OrderPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="#121212")
        self.controller = controller
        self.cart = {}

        title = tk.Label(self, text="Order Your Favorite Fast Food 🍔", bg="#121212", fg="white",
                         font=("Poppins", 20, "bold"))
        title.pack(pady=20)

        # ----- Customer Info -----
        form_frame = tk.Frame(self, bg="#121212")
        form_frame.pack(pady=10)

        self.name_var = tk.StringVar()
        self.country_var = tk.StringVar()
        self.city_var = tk.StringVar()

        self.create_entry(form_frame, "Full Name", self.name_var)
        self.create_entry(form_frame, "Country", self.country_var)
        self.create_entry(form_frame, "City", self.city_var)

        # ----- Menu Items -----
        self.menu_items = [
            {"name": "Burger", "price": 25},
            {"name": "Pizza", "price": 40},
            {"name": "Fries", "price": 10},
            {"name": "Coke", "price": 5}
        ]

        menu_frame = tk.Frame(self, bg="#121212")
        menu_frame.pack(pady=10)

        for item in self.menu_items:
            btn = tk.Button(menu_frame,
                            text=f"{item['name']} - ${item['price']}",
                            font=("Poppins", 14),
                            bg="#FF4500",
                            fg="white",
                            activebackground="#FF6347",
                            activeforeground="white",
                            width=20,
                            command=lambda i=item: self.add_to_cart(i))
            btn.pack(pady=5)

        # ----- Order Details -----
        self.order_summary = tk.Label(self, text="🛒 Cart is empty", bg="#121212", fg="white", font=("Poppins", 14), justify="left")
        self.order_summary.pack(pady=20)

        # ----- Submit Button -----
        submit_btn = tk.Button(self, text="✔ Confirm Order", font=("Poppins", 14, "bold"),
                               bg="#32CD32", fg="white", padx=10, pady=5,
                               command=self.show_order_details)
        submit_btn.pack(pady=10)

    def create_entry(self, parent, label_text, text_var):
        label = tk.Label(parent, text=label_text, bg="#121212", fg="white", font=("Poppins", 12, "bold"))
        label.pack(anchor="w", pady=2)
        entry = tk.Entry(parent, textvariable=text_var, font=("Poppins", 12), width=30)
        entry.pack(pady=2)

    def add_to_cart(self, item):
        name = item['name']
        self.cart[name] = self.cart.get(name, 0) + 1
        self.update_cart_label()

    def update_cart_label(self):
        if not self.cart:
            self.order_summary.config(text="🛒 Cart is empty")
        else:
            cart_text = "🛒 Your Cart:\n"
            for k, v in self.cart.items():
                cart_text += f"• {k}: {v}\n"
            self.order_summary.config(text=cart_text)

    def show_order_details(self):
        name = self.name_var.get()
        country = self.country_var.get()
        city = self.city_var.get()

        if not name or not country or not city or not self.cart:
            self.order_summary.config(text="⚠ Please fill in all details and add items to cart.")
            return

        order_text = f"✅ Order Summary:\n\n👤 Name: {name}\n🌍 Country: {country}\n🏙 City: {city}\n\n🍽 Items Ordered:\n"
        for item, qty in self.cart.items():
            order_text += f"• {item}: {qty}\n"

        self.order_summary.config(text=order_text)
