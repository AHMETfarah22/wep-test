import tkinter as tk

class DashboardPage(tk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent, bg="#121212")
        self.controller = controller

        title = tk.Label(self, text="Sales Dashboard", bg="#121212", fg="white",
                         font=("Poppins", 18, "bold"))
        title.pack(pady=20)

        info = tk.Label(self, text="(This is a placeholder for charts and reports)", 
                        bg="#121212", fg="gray80", font=("Poppins", 14))
        info.pack(pady=10)
